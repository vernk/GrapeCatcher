 
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
 
public class DobleBufferJFrame extends JFrame implements KeyListener {
     
    //Objects for images
    private BufferedImage background;
    private BufferedImage bird;
    //First coordinates of bird image
    private int cordX = 273;
    private int cordY = 607;
    //Objects for doble buffer
    private BufferStrategy myBuffer;
 
    public DobleBufferJFrame() {
        setTitle("Grape Catcher Sample");
        //set window dimension 480x320px
        setSize(600, 750);
        //load images...
        loadImages();
        //make window visible
        setVisible(true);
        //Ignore OS paint calls
        setIgnoreRepaint(true);
 
        //create a doble buffer objects
        //NOTE: It's very important to create bufferStrategy after
        //JFrame is visible, in other case fail!
        this.createBufferStrategy(2);
        myBuffer = this.getBufferStrategy();
        //call explicit to paint first time
        repaint();
    }
 
    public void loadImages() {
        try {
            //path for image file
            String pathBackground = "Home.png";
            background = ImageIO.read(new File(pathBackground));
            String pathBird = "Duck.png";
            bird = ImageIO.read(new File(pathBird));
 
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        //asociate the keyboard listener with this JFrame
        addKeyListener(this);
    }
 
    public void drawImages(Graphics2D g) {
        //draw brackground image (first image)
        g.drawImage(background, 0, 0, this);
        //draw bird image (second image, in this order)
        g.drawImage(bird, cordX, cordY, this);
    }
 
    public void paint(Graphics g) {
        Graphics2D g2 = null;
        if (myBuffer != null) {
            try {
                //get the graphics2d object of the buffer
                g2 = (Graphics2D) myBuffer.getDrawGraphics();
                //draw images in buffer
                drawImages(g2);
            } finally {
                g2.dispose();
            }
            //draw the content of buffer in the screen
            myBuffer.show();
        }
    }
 
    public static void main(String[] args) {
        new DobleBufferJFrame();
    }
 
    //While a key is pressed
    public void keyPressed(KeyEvent ke) {
        switch (ke.getKeyCode()) {
            //if the right arrow in keyboard is pressed...
            case KeyEvent.VK_RIGHT: {
               if (cordX <= 545)
            	cordX +=15;
            }
            break;
 
            //if the left arrow in keyboard is pressed...
            case KeyEvent.VK_LEFT: {
            	if (cordX >= 10)
            	cordX -=15;
            }
            break;
 
            //if the down arrow in keyboard is pressed...
            case KeyEvent.VK_DOWN: {
              // cordY ++;
            }
            break;
 
            //if the up arrow in keyboard is pressed...
            case KeyEvent.VK_UP: {
               // cordY --;
            }
            break;
 
        } 
        //call explicit to paint
        repaint();
 
 
    }
 
    //When a key is typed (once)
    public void keyTyped(KeyEvent ke) {
    }
 
    //When a key is released (typed or pressed)
    public void keyReleased(KeyEvent ke) {
    }
}